(() => {
  'use strict';
  const DB = Array.isArray(window.FOOD_DATABASE) ? window.FOOD_DATABASE : [];
  const STORAGE_KEY = 'tinyFoodDatePicker_v2';
  const ALLERGEN_LABELS = {
    peanut: 'peanuts', 'tree-nut': 'tree nuts', sesame: 'sesame', soy: 'soy', wheat: 'wheat / gluten',
    dairy: 'milk / dairy', egg: 'egg', fish: 'fish', crustacean: 'shrimp / crab', mollusc: 'clams / squid'
  };
  const MEAL_LABELS = { breakfast: 'Breakfast', lunch: 'Lunch', dinner: 'Dinner', snack: 'Snack / sweet' };
  const MOODS = {
    comfort: { emoji: '🫶', title: 'Comfort me', copy: 'Something cosy, warming and reassuring.' },
    spicy: { emoji: '🌶️', title: 'Spicy chaos', copy: 'A little excitement and a little kick — within your spice limit.' },
    fresh: { emoji: '🍃', title: 'Fresh & light', copy: 'Something bright and refreshing without feeling too heavy.' },
    hearty: { emoji: '🍚', title: 'Properly hungry', copy: 'A proper meal that feels satisfying and worth the wait.' },
    lazy: { emoji: '🛋️', title: 'Lazy mode', copy: 'Low effort, easy to order, and absolutely no pressure to cook.' },
    sweet: { emoji: '🍓', title: 'Treat myself', copy: 'A little sweetness, dessert, or a small treat.' },
    surprise: { emoji: '🎲', title: 'Surprise me', copy: 'No overthinking. Let the food universe make the call.' }
  };
  const emptyProfile = () => ({ hasAllergies: false, allergies: [], diet: [], spice: 2, dislikes: [] });
  const defaultState = () => ({
    meal: 'dinner', plan: 'takeout', mode: 'solo', person: 'me', mood: 'surprise',
    profiles: { me: emptyProfile(), partner: emptyProfile() },
    favorites: [], history: []
  });
  let state = loadState();
  let selectedFood = null;
  let seenThisRound = [];
  let rerollsLeft = 2;
  let hasSpun = false;
  let isSpinning = false;
  let toastTimer = null;

  const $ = (selector, root = document) => root.querySelector(selector);
  const $$ = (selector, root = document) => Array.from(root.querySelectorAll(selector));

  function loadState() {
    const base = defaultState();
    try {
      const saved = JSON.parse(localStorage.getItem(STORAGE_KEY) || localStorage.getItem('tinyFoodDatePicker_v1') || 'null');
      if (!saved || typeof saved !== 'object') return base;
      const profiles = saved.profiles || {};
      const mergeProfile = key => ({ ...emptyProfile(), ...(profiles[key] || {}) });
      return {
        ...base,
        meal: ['breakfast', 'lunch', 'dinner', 'snack'].includes(saved.meal) ? saved.meal : base.meal,
        plan: ['takeout', 'restaurant', 'maybe-cook', 'cook'].includes(saved.plan) ? saved.plan : base.plan,
        mode: ['solo', 'together'].includes(saved.mode) ? saved.mode : 'solo',
        person: saved.person === 'partner' ? 'partner' : 'me',
        mood: Object.prototype.hasOwnProperty.call(MOODS, saved.mood) ? saved.mood : 'surprise',
        profiles: { me: mergeProfile('me'), partner: mergeProfile('partner') },
        favorites: Array.isArray(saved.favorites) ? saved.favorites.filter(id => DB.some(f => f.id === id)) : [],
        history: Array.isArray(saved.history) ? saved.history.filter(id => DB.some(f => f.id === id)).slice(0, 12) : []
      };
    } catch (_error) {
      return base;
    }
  }

  function persist() {
    try { localStorage.setItem(STORAGE_KEY, JSON.stringify(state)); } catch (_error) { /* App still works if browser storage is blocked. */ }
  }

  function toast(message) {
    const el = $('#toast');
    el.textContent = message;
    el.classList.add('show');
    clearTimeout(toastTimer);
    toastTimer = setTimeout(() => el.classList.remove('show'), 2400);
  }

  function showScreen(name) {
    $$('.screen').forEach(el => el.classList.toggle('active', el.id === `screen-${name}`));
    window.scrollTo({ top: 0, behavior: 'smooth' });
  }

  function foodById(id) { return DB.find(food => food.id === id); }
  function imagePath(food) { return food ? (food.image || `food-images/${food.id}.svg`) : 'food-images/hotpot.svg'; }

  function selectCardGroup(groupSelector, attrName, value) {
    $$(groupSelector).forEach(button => {
      const selected = button.dataset[attrName] === value;
      button.classList.toggle('selected', selected);
      if (button.hasAttribute('aria-selected')) button.setAttribute('aria-selected', selected ? 'true' : 'false');
    });
  }

  function renderModeControls() {
    if (state.mode === 'solo') state.person = 'me';
    selectCardGroup('#mode-options [data-mode]', 'mode', state.mode);
    $$('#mode-options [data-mode]').forEach(button => {
      button.setAttribute('aria-pressed', button.dataset.mode === state.mode ? 'true' : 'false');
    });
    $('.profile-tabs').classList.toggle('hidden', state.mode !== 'together');
    selectCardGroup('.profile-tabs [data-person]', 'person', state.person);
    $('#profile-heading').textContent = state.mode === 'solo'
      ? 'Your preferences'
      : (state.person === 'me' ? 'Person 1 preferences' : 'Person 2 preferences');
    $('#profile-desc').textContent = state.mode === 'solo'
      ? 'Only your preferences will shape the food suggestions.'
      : 'Set both people’s needs; suggestions must work for both.';
  }

  function renderBasicSettings() {
    selectCardGroup('#meal-options [data-meal]', 'meal', state.meal);
    selectCardGroup('#plan-options [data-plan]', 'plan', state.plan);
    renderModeControls();
    $$('.spice-button').forEach(button => {
      button.classList.toggle('selected', Number(button.dataset.spice) === state.profiles[state.person].spice);
    });
    $('#favorite-count').textContent = state.favorites.length;
  }

  function renderPreferenceControls() {
    renderModeControls();
    const profile = state.profiles[state.person];
    $('#allergy-toggle').checked = !!profile.hasAllergies;
    $('#allergy-options').classList.toggle('hidden', !profile.hasAllergies);
    $$('#allergy-checks input').forEach(input => { input.checked = profile.allergies.includes(input.value); });
    $('#pork-free-toggle').checked = profile.diet.includes('pork');
    $$('#diet-checks input').forEach(input => { input.checked = profile.diet.includes(input.value); });
    $$('#dislike-checks input').forEach(input => { input.checked = profile.dislikes.includes(input.value); });
    $$('.spice-button').forEach(button => button.classList.toggle('selected', Number(button.dataset.spice) === profile.spice));
    $('#favorite-count').textContent = state.favorites.length;
  }

  function selectedValues(containerSelector) {
    return $$(containerSelector + ' input:checked').map(input => input.value);
  }

  function renderMood() {
    selectCardGroup('#mood-options [data-mood]', 'mood', state.mood);
    const mood = MOODS[state.mood] || MOODS.surprise;
    const solo = state.mode === 'solo';
    $('#mood-side-emoji').textContent = mood.emoji;
    $('#mood-side-title').textContent = state.mood === 'surprise'
      ? (solo ? 'One hungry person. One delicious answer.' : 'Two people. One delicious answer.')
      : mood.title + '.';
    $('#mood-side-copy').textContent = state.mood === 'surprise'
      ? (solo ? 'No more scrolling endlessly and still not knowing what to order.' : 'No more “anything is fine” followed by rejecting every suggestion.')
      : mood.copy;
    $('#mood-side-note').textContent = solo ? 'MADE FOR YOUR NEXT CRAVING ♡' : 'MADE FOR SHARED MEAL DECISIONS ♡';
  }

  function effectivePreferences() {
    const profiles = state.mode === 'together'
      ? [state.profiles.me, state.profiles.partner]
      : [state.profiles.me];
    const allergies = new Set();
    const diet = new Set();
    const dislikes = new Set();
    profiles.forEach(profile => {
      if (profile.hasAllergies) profile.allergies.forEach(value => allergies.add(value));
      profile.diet.forEach(value => diet.add(value));
      profile.dislikes.forEach(value => dislikes.add(value));
    });
    return {
      allergies: Array.from(allergies),
      diet: Array.from(diet),
      dislikes: Array.from(dislikes),
      maxSpice: Math.min(...profiles.map(profile => Number.isFinite(profile.spice) ? profile.spice : 2))
    };
  }

  function mealMatches(food) {
    if (state.meal === 'snack') return food.meal.some(tag => ['snack', 'dessert', 'drink'].includes(tag));
    return food.meal.includes(state.meal);
  }

  function getEligiblePool() {
    const prefs = effectivePreferences();
    return DB.filter(food => {
      if (!mealMatches(food)) return false;
      if (state.plan === 'cook' && !food.homeCook) return false;
      if (food.allergens.some(allergen => prefs.allergies.includes(allergen))) return false;
      if (prefs.diet.includes('vegetarian') && !food.diet.includes('vegetarian')) return false;
      const nonVegAvoids = prefs.diet.filter(value => value !== 'vegetarian');
      if (food.diet.some(tag => nonVegAvoids.includes(tag))) return false;
      // The pork-free switch also excludes dishes that are commonly prepared with pork,
      // even where a restaurant may offer a different variant. This is a conservative cue, not a safety guarantee.
      if (prefs.diet.includes('pork') && food.porkRisk === true) return false;
      if (food.dislikes.some(tag => prefs.dislikes.includes(tag))) return false;
      if (food.spice > prefs.maxSpice) return false;
      return true;
    });
  }

  function weightedPick(pool) {
    const mood = state.mood;
    const weights = pool.map(food => {
      let weight = 1;
      if (mood !== 'surprise' && food.mood.includes(mood)) weight += 3.2;
      if (state.plan === 'maybe-cook' && food.homeCook) weight *= 0.32;
      if (state.meal === 'snack' && ['dessert', 'drink'].some(tag => food.meal.includes(tag))) weight *= 1.1;
      return Math.max(0.05, weight);
    });
    const total = weights.reduce((sum, value) => sum + value, 0);
    let r = Math.random() * total;
    for (let index = 0; index < pool.length; index++) {
      r -= weights[index];
      if (r <= 0) return pool[index];
    }
    return pool[pool.length - 1];
  }

  function renderSpinFood(food) {
    if (!food) return;
    $('#spin-image').src = imagePath(food);
    $('#spin-image').alt = `${food.en} offline illustration`;
    $('#spin-name-cn').textContent = food.cn;
    $('#spin-name-en').textContent = food.en;
    $('#spin-region').textContent = food.region;
  }

  function setRerollCounter() {
    const dots = $$('.reroll-dot');
    dots.forEach((dot, i) => dot.classList.toggle('used', i >= rerollsLeft));
    const label = $('#reroll-counter span:last-child');
    label.textContent = `${rerollsLeft} left`;
    $('#reroll-button').disabled = rerollsLeft <= 0 || isSpinning;
    $('#reroll-button').textContent = rerollsLeft > 0 ? '↻ Shuffle again' : 'No rerolls left';
  }

  function prepareSpinScreen() {
    selectedFood = null;
    seenThisRound = [];
    rerollsLeft = 2;
    hasSpun = false;
    isSpinning = false;
    $('#spin-card').classList.remove('spinning');
    $('#back-mood').disabled = false;
    $('#spin-button').classList.remove('hidden');
    $('#spin-button').disabled = false;
    $('#result-detail').classList.remove('visible');
    $('#done-message').classList.remove('visible');
    $('#cook-recipe').classList.add('hidden');
    $('#empty-pool').classList.add('hidden');
    $('#roulette-area').classList.remove('hidden');
    $('#spin-button').innerHTML = state.mode === 'solo'
      ? 'Spin for my food <span>🎲</span>'
      : 'Spin for our food <span>🎲</span>'; 
    $('#accept-pick').textContent = state.mode === 'solo' ? 'I’ll pick this ♡' : 'We’ll pick this ♡';
    $('#spin-image').src = 'food-images/hotpot.svg';
    $('#spin-name-cn').textContent = '准备好了吗？';
    $('#spin-name-en').textContent = 'Ready to find something yummy?';
    $('#spin-region').textContent = 'YOUR NEXT MEAL';
    const pool = getEligiblePool();
    const mealLabel = MEAL_LABELS[state.meal] || 'Food';
    $('#filter-count').textContent = `${pool.length} ${pool.length === 1 ? 'idea fits' : 'ideas fit'} your ${mealLabel.toLowerCase()} filters.`;
    $('#spin-subtitle').textContent = state.plan === 'cook'
      ? 'We’ll find a home-cookable dish and give you a simple starting recipe.'
      : (state.mode === 'solo'
        ? 'A little spin, a tiny bit of suspense, and one less decision to make.'
        : 'A little spin, a tiny bit of suspense, and one less decision to make together.');
    setRerollCounter();
    if (pool.length === 0) {
      $('#empty-pool').classList.remove('hidden');
      $('#roulette-area').classList.add('hidden');
    }
  }

  function renderResult(food) {
    $('#result-title').textContent = `${food.cn} — this could be the one.`;
    $('#result-note').textContent = food.note;
    const tags = [];
    tags.push(food.region);
    tags.push(food.spice === 0 ? 'Mild' : food.spice === 1 ? 'A little kick' : food.spice === 2 ? 'Spicy' : 'Very spicy');
    if (food.homeCook) tags.push('Can cook at home');
    if (food.meal.includes('breakfast')) tags.push('Breakfast-friendly');
    $('#dish-tags').replaceChildren(...tags.map(tag => {
      const span = document.createElement('span');
      span.className = 'dish-tag'; span.textContent = tag; return span;
    }));
    if (state.plan === 'cook' && Array.isArray(food.recipe) && food.recipe.length) {
      $('#recipe-steps').replaceChildren(...food.recipe.map(line => {
        const li = document.createElement('li'); li.textContent = line; return li;
      }));
      $('#cook-recipe').classList.remove('hidden');
    } else {
      $('#cook-recipe').classList.add('hidden');
    }
    const isSaved = state.favorites.includes(food.id);
    $('#save-favorite').textContent = isSaved ? '♥ Saved favourite' : '♡ Save favourite';
    $('#accept-pick').textContent = state.mode === 'solo' ? 'I’ll pick this ♡' : 'We’ll pick this ♡';
    $('#result-detail').classList.add('visible');
    $('#done-message').classList.remove('visible');
    $('#spin-button').classList.add('hidden');
    $('#spin-card').classList.remove('spinning');
    setRerollCounter();
  }

  function runSpin(isReroll = false) {
    if (isSpinning) return;
    const pool = getEligiblePool();
    if (!pool.length) {
      $('#empty-pool').classList.remove('hidden');
      $('#roulette-area').classList.add('hidden');
      return;
    }
    if (isReroll && rerollsLeft <= 0) {
      toast('No rerolls left this round. You can start a new round ♡');
      return;
    }
    if (isReroll) {
      rerollsLeft -= 1;
      setRerollCounter();
    }
    isSpinning = true;
    $('#back-mood').disabled = true;
    $('#spin-button').disabled = true;
    $('#reroll-button').disabled = true;
    $('#result-detail').classList.remove('visible');
    $('#done-message').classList.remove('visible');
    $('#spin-card').classList.add('spinning');

    let candidates = pool.filter(food => !seenThisRound.includes(food.id));
    if (!candidates.length) {
      candidates = pool;
      if (pool.length === 1) toast('This is the only match that fits every filter.');
      else toast('You’ve seen the whole shortlist — duplicates are possible now.');
    }
    // Gently reduce repeats from the last few chosen meals when there are plenty of alternatives.
    if (candidates.length > 5) {
      const fresh = candidates.filter(food => !state.history.slice(0, 5).includes(food.id));
      if (fresh.length >= 3) candidates = fresh;
    }
    const winner = weightedPick(candidates);
    let tick = 0;
    const maxTicks = 25;
    const timerTick = () => {
      if (tick < maxTicks - 1) {
        const preview = pool[Math.floor(Math.random() * pool.length)];
        renderSpinFood(preview);
        tick += 1;
        const delay = 48 + tick * tick * 0.30;
        setTimeout(timerTick, delay);
        return;
      }
      renderSpinFood(winner);
      selectedFood = winner;
      seenThisRound.push(winner.id);
      hasSpun = true;
      isSpinning = false;
      $('#back-mood').disabled = false;
      $('#spin-button').disabled = false;
      renderResult(winner);
      setRerollCounter();
    };
    timerTick();
  }

  function saveFavorite(food) {
    if (!food) return;
    const index = state.favorites.indexOf(food.id);
    if (index >= 0) {
      state.favorites.splice(index, 1);
      toast('Removed from your saved cravings.');
    } else {
      state.favorites.unshift(food.id);
      toast('Saved for another hungry day ♡');
    }
    persist();
    $('#favorite-count').textContent = state.favorites.length;
    $('#save-favorite').textContent = state.favorites.includes(food.id) ? '♥ Saved favourite' : '♡ Save favourite';
    if ($('#favorites-dialog').open) renderFavorites();
  }

  function renderFavorites() {
    const list = $('#favorites-list');
    list.replaceChildren();
    const foods = state.favorites.map(foodById).filter(Boolean);
    if (!foods.length) {
      const empty = document.createElement('div');
      empty.className = 'no-favs';
      empty.textContent = 'No saved cravings yet. When a dish looks good, tap “Save favourite” and it will live here.';
      list.appendChild(empty);
      return;
    }
    foods.forEach(food => {
      const row = document.createElement('div'); row.className = 'favorite-row';
      const img = document.createElement('img'); img.src = imagePath(food); img.alt = `${food.en} illustration`;
      const main = document.createElement('div'); main.className = 'favorite-main';
      const strong = document.createElement('strong'); strong.textContent = food.cn;
      const sub = document.createElement('span'); sub.textContent = food.en;
      main.append(strong, sub);
      const remove = document.createElement('button'); remove.type = 'button'; remove.className = 'remove-fav'; remove.textContent = 'Remove';
      remove.addEventListener('click', () => {
        state.favorites = state.favorites.filter(id => id !== food.id);
        persist(); renderFavorites(); renderBasicSettings();
        if (selectedFood && selectedFood.id === food.id) $('#save-favorite').textContent = '♡ Save favourite';
      });
      row.append(img, main, remove); list.appendChild(row);
    });
  }

  function currentAppUrl() {
    return location.protocol === 'http:' || location.protocol === 'https:' ? location.href : '';
  }

  async function shareContent(title, message, includeAppUrl = true) {
    const url = includeAppUrl ? currentAppUrl() : '';
    if (navigator.share) {
      try {
        const payload = { title, text: message };
        if (url) payload.url = url;
        await navigator.share(payload);
        return;
      } catch (error) {
        if (error && error.name === 'AbortError') return;
      }
    }
    const copyText = url ? `${message}\n\nTry the food picker: ${url}` : message;
    try {
      if (navigator.clipboard && window.isSecureContext) {
        await navigator.clipboard.writeText(copyText);
        toast('Copied — ready to send ♡');
        return;
      }
    } catch (_error) { /* Use the manual fallback below. */ }
    const helper = document.createElement('textarea');
    helper.value = copyText;
    helper.setAttribute('readonly', '');
    helper.style.position = 'fixed'; helper.style.opacity = '0';
    document.body.appendChild(helper); helper.select();
    let copied = false;
    try { copied = document.execCommand('copy'); } catch (_error) { /* Manual copy prompt below. */ }
    helper.remove();
    if (copied) toast('Copied — ready to send ♡');
    else window.prompt('Copy this message to share:', copyText);
  }

  function shareApp() {
    const url = currentAppUrl();
    if (!url) {
      toast('Publish the project online first, then this button can share its link.');
      return;
    }
    shareContent('今晚吃什么？ — What Are We Eating?', 'A little Chinese food picker for your next craving. Open the link, set your own preferences and spin for a dish.');
  }

  function sharePick() {
    if (!selectedFood) {
      toast('Spin for a dish first, then share your pick.');
      return;
    }
    const lead = state.mode === 'solo' ? 'Food idea for you' : 'Food idea for us';
    const message = `${lead}: ${selectedFood.cn} — ${selectedFood.en}. ${selectedFood.note}`;
    shareContent('Food pick: ' + selectedFood.en, message);
  }

  function confirmPick() {
    if (!selectedFood) return;
    state.history = [selectedFood.id, ...state.history.filter(id => id !== selectedFood.id)].slice(0, 12);
    persist();
    const message = state.mode === 'solo'
      ? `Decision made ✨ 今晚吃 ${selectedFood.cn} (${selectedFood.en}). That's your next meal sorted!`
      : `Decision made 💗 今晚吃 ${selectedFood.cn} (${selectedFood.en}). Send this pick to the other person and enjoy!`;
    $('#done-message').textContent = message;
    $('#done-message').classList.add('visible');
    toast('A decision has been made. Victory!');
  }

  function resetPreferences() {
    const keep = { favorites: state.favorites.slice(), history: state.history.slice() };
    state = defaultState();
    state.favorites = keep.favorites;
    state.history = keep.history;
    persist();
    renderBasicSettings();
    renderPreferenceControls();
    renderMood();
    toast('Preferences reset. Your favourites are still saved.');
  }

  // Who is the picker for? Solo mode only uses Person 1's preferences; together mode combines both.
  $$('#mode-options [data-mode]').forEach(button => button.addEventListener('click', () => {
    state.mode = button.dataset.mode;
    if (state.mode === 'solo') state.person = 'me';
    persist();
    renderBasicSettings();
    renderPreferenceControls();
    renderMood();
  }));

  // Meal and plan selectors.
  $$('#meal-options [data-meal]').forEach(button => button.addEventListener('click', () => {
    state.meal = button.dataset.meal; persist(); renderBasicSettings();
  }));
  $$('#plan-options [data-plan]').forEach(button => button.addEventListener('click', () => {
    state.plan = button.dataset.plan; persist(); renderBasicSettings();
  }));

  // Which person's profile is being edited.
  $$('.people-tabs [data-person]').forEach(button => button.addEventListener('click', () => {
    state.person = button.dataset.person; persist(); renderPreferenceControls();
  }));
  $('#allergy-toggle').addEventListener('change', event => {
    state.profiles[state.person].hasAllergies = event.target.checked;
    persist(); renderPreferenceControls();
  });
  $$('#allergy-checks input').forEach(input => input.addEventListener('change', () => {
    state.profiles[state.person].allergies = selectedValues('#allergy-checks');
    // Selecting an allergy automatically turns the profile's allergy flag on.
    if (state.profiles[state.person].allergies.length) state.profiles[state.person].hasAllergies = true;
    persist(); renderPreferenceControls();
  }));
  $('#pork-free-toggle').addEventListener('change', event => {
    const profile = state.profiles[state.person];
    const diet = new Set(profile.diet);
    if (event.target.checked) diet.add('pork');
    else diet.delete('pork');
    profile.diet = Array.from(diet);
    persist();
    renderPreferenceControls();
  });
  $$('#diet-checks input').forEach(input => input.addEventListener('change', () => {
    state.profiles[state.person].diet = [
      ...selectedValues('#diet-checks'),
      ...(state.profiles[state.person].diet.includes('pork') ? ['pork'] : [])
    ];
    persist();
  }));
  $$('#dislike-checks input').forEach(input => input.addEventListener('change', () => {
    state.profiles[state.person].dislikes = selectedValues('#dislike-checks');
    persist();
  }));
  $$('.spice-button').forEach(button => button.addEventListener('click', () => {
    state.profiles[state.person].spice = Number(button.dataset.spice);
    persist(); renderPreferenceControls();
  }));

  $$('#mood-options [data-mood]').forEach(button => button.addEventListener('click', () => {
    state.mood = button.dataset.mood; persist(); renderMood();
  }));
  $('#to-mood').addEventListener('click', () => {
    const profileKeys = state.mode === 'together' ? ['me', 'partner'] : ['me'];
    const incompleteAllergyProfile = profileKeys.some(key => state.profiles[key].hasAllergies && state.profiles[key].allergies.length === 0);
    if (incompleteAllergyProfile) {
      toast('For anyone marked as having allergies, select the allergy types first.');
      return;
    }
    renderMood(); showScreen('mood');
  });
  $('#back-setup').addEventListener('click', () => showScreen('setup'));
  $('#to-spin').addEventListener('click', () => {
    if (!state.mood) state.mood = 'surprise';
    prepareSpinScreen(); showScreen('spin');
  });
  $('#back-mood').addEventListener('click', () => { showScreen('mood'); });
  $('#spin-button').addEventListener('click', () => runSpin(false));
  $('#reroll-button').addEventListener('click', () => runSpin(true));
  $('#accept-pick').addEventListener('click', confirmPick);
  $('#save-favorite').addEventListener('click', () => saveFavorite(selectedFood));
  $('#share-pick').addEventListener('click', sharePick);
  $('#share-app').addEventListener('click', shareApp);
  $('#edit-filters').addEventListener('click', () => showScreen('setup'));
  $('#reset-settings').addEventListener('click', resetPreferences);

  $('#open-favorites').addEventListener('click', () => {
    renderFavorites();
    const dialog = $('#favorites-dialog');
    if (typeof dialog.showModal === 'function') dialog.showModal();
    else dialog.setAttribute('open', '');
  });
  $('#close-favorites').addEventListener('click', () => {
    const dialog = $('#favorites-dialog');
    if (typeof dialog.close === 'function') dialog.close();
    else dialog.removeAttribute('open');
  });
  $('#favorites-dialog').addEventListener('click', event => {
    if (event.target === $('#favorites-dialog')) {
      const dialog = $('#favorites-dialog');
      if (typeof dialog.close === 'function') dialog.close();
      else dialog.removeAttribute('open');
    }
  });

  renderBasicSettings();
  renderPreferenceControls();
  renderMood();
  $('#favorite-count').textContent = state.favorites.length;

  // When hosted on HTTPS, cache the app shell for repeat offline use. file:// use already loads local assets directly.
  if ('serviceWorker' in navigator && (location.protocol === 'https:' || location.protocol === 'http:')) {
    navigator.serviceWorker.register('./service-worker.js').catch(() => {});
  }
})();
