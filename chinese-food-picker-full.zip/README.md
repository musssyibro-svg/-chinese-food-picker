今晚吃什么？ — WHAT ARE WE EATING?
A shareable, offline-first Chinese food picker for one person or two.

WHAT'S INCLUDED
- 53 Chinese dish ideas, with Chinese and English names.
- 53 locally bundled SVG dish illustrations (illustrations, not real dish photos).
- Two modes: “Just me” and “Two people”.
- Solo mode uses only Person 1's preferences. Two-people mode combines both profiles conservatively.
- Allergy screening, dietary restrictions, dislikes and spice preferences.
- Breakfast, lunch, dinner and snack/dessert modes.
- Takeaway, eat-out, occasional-cooking and cook-at-home modes.
- Mood-weighted roulette, two rerolls per round, favourites and recent-pick avoidance.
- Share-app and share-dish buttons on supported browsers/devices.
- No APIs, AI calls, external fonts, remote images or tracking.
- Optional service worker for offline use after the first visit when hosted on HTTPS.

QUICK START ON A COMPUTER
1. Extract the ZIP into one folder.
2. Keep index.html, app.js, food-data.js, service-worker.js, manifest.webmanifest, app-icon.svg and food-images/ together.
3. Open index.html in a modern browser such as Chrome or Edge.
4. Choose “Just me” or “Two people”, set the relevant preferences, pick a mood and spin.

MAKE IT SHAREABLE WITH A LINK
Opening index.html locally is good for testing, but a file:// page does not give friends a usable public link. Deploy the whole project as a static site. See DEPLOY.md for the quickest option through Cloudflare Pages. Once hosted, press “Share app” and send the generated website link. Anyone with the link can use it.

HOW PERSONAL SETTINGS WORK
- Preferences, favourites and recent picks save in local storage on the current browser/device.
- Your girlfriend or a friend can use the same public URL and make their own setup on their own phone/computer.
- Their settings do not overwrite yours and no account is required.
- Settings do not automatically sync between devices. To use “Two people”, enter both people's preferences on one device. A dish can be shared using “Share this dish”.
- Clearing browser data or switching browsers/devices may remove or not carry over that local setup.

PHONE / ADD TO HOME SCREEN
For the most reliable phone experience, deploy to an HTTPS static host, open the link once while online, and use the browser's Add to Home Screen option. The service worker caches the app shell and bundled illustrations for repeat offline visits. Service workers do not work when a page is opened as a file:// URL.

ALLERGY SAFETY — IMPORTANT
The allergy list filters dishes based on the library's tagged/common possible ingredients. Chinese dishes and restaurant recipes vary; hidden ingredients and cross-contact are possible. No untagged dish is guaranteed allergy-safe. Always confirm ingredients and cross-contact directly with the restaurant or cook, especially for serious allergies. This is a meal-idea tool, not a safety guarantee.

HOW TO ADD A DISH
Open food-data.js and add another object to window.FOOD_DATABASE. Each dish needs a unique id and should include:
  id, cn, en, region, meal, mood, allergens, diet, dislikes, spice, homeCook, note
By default, its illustration path is food-images/<id>.svg. You can also set an explicit image property, for example:
  image: 'food-images/my-dish.jpg'
For the added image to work offline on the hosted/PWA version, add its path to APP_FILES in service-worker.js and change CACHE_NAME to a new version so devices refresh the cache.

PROJECT FILES
index.html          Interface and styling
app.js              Filtering, solo/shared mode, roulette, sharing, favourites and settings
food-data.js        Editable 53-dish library
food-images/        Bundled local illustrations
manifest.webmanifest Install metadata
service-worker.js   Cache for offline use on HTTPS
app-icon.svg        App icon
DEPLOY.md           Steps to publish and share one public link
PRODUCT-BRIEF.md    Product scope and feature notes
### Pork-free filter

The setup screen includes a one-tap **Pork-free dishes only** switch for the active profile. In two-person mode, each profile can set it independently and the combined picker honours both. The setting is stored only in that browser on that device. It excludes dishes explicitly tagged with pork and dishes flagged as commonly prepared with pork (for example, variable fillings, pork-based broth or lard). Restaurant recipes can vary, so confirm broths, sauces, cooking oils and preparation with the restaurant; this filter is not a guarantee of dietary safety.
