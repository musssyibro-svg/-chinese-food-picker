const CACHE_NAME = 'food-picker-v3';
const APP_FILES = [
  "./",
  "./index.html",
  "./app.js",
  "./food-data.js",
  "./manifest.webmanifest",
  "./app-icon.svg",
  "./food-images/baozi-veg.svg",
  "./food-images/baozi.svg",
  "./food-images/beef-noodles.svg",
  "./food-images/braised-pork-rice.svg",
  "./food-images/cantonese-roast.svg",
  "./food-images/chongqing-noodles.svg",
  "./food-images/congee.svg",
  "./food-images/cucumber-salad.svg",
  "./food-images/dapanji.svg",
  "./food-images/double-skin-milk.svg",
  "./food-images/dry-pot-cauliflower.svg",
  "./food-images/duck-rice.svg",
  "./food-images/dumplings.svg",
  "./food-images/egg-tart.svg",
  "./food-images/egg-waffle.svg",
  "./food-images/fish-fragrant-pork.svg",
  "./food-images/garlic-greens.svg",
  "./food-images/hand-pulled-noodles.svg",
  "./food-images/hot-dry-noodles.svg",
  "./food-images/hotpot.svg",
  "./food-images/huangmenji.svg",
  "./food-images/jianbing.svg",
  "./food-images/kung-pao.svg",
  "./food-images/lemon-tea.svg",
  "./food-images/liangpi.svg",
  "./food-images/lotus-root.svg",
  "./food-images/malatang.svg",
  "./food-images/mapo-tofu.svg",
  "./food-images/milk-tea.svg",
  "./food-images/osmanthus-cake.svg",
  "./food-images/red-bean-soup.svg",
  "./food-images/rice-noodles.svg",
  "./food-images/rice-rolls.svg",
  "./food-images/roujiamo.svg",
  "./food-images/scallion-noodles.svg",
  "./food-images/scallion-pancake.svg",
  "./food-images/shuizhu-fish.svg",
  "./food-images/sichuan-skewers.svg",
  "./food-images/sour-plum.svg",
  "./food-images/sour-potato.svg",
  "./food-images/soy-milk.svg",
  "./food-images/stinky-tofu.svg",
  "./food-images/stirfried-rice-cakes.svg",
  "./food-images/suan-cai-fish.svg",
  "./food-images/tanghulu.svg",
  "./food-images/tea-egg.svg",
  "./food-images/tofu-pudding.svg",
  "./food-images/tomato-egg.svg",
  "./food-images/wonton.svg",
  "./food-images/xiaolongbao.svg",
  "./food-images/yangrouchuan.svg",
  "./food-images/yangzhou-fried-rice.svg",
  "./food-images/youtiao.svg"
];

self.addEventListener('install', event => {
  event.waitUntil(caches.open(CACHE_NAME).then(cache => cache.addAll(APP_FILES)).then(() => self.skipWaiting()));
});

self.addEventListener('activate', event => {
  event.waitUntil(
    caches.keys()
      .then(keys => Promise.all(keys.filter(key => key !== CACHE_NAME).map(key => caches.delete(key))))
      .then(() => self.clients.claim())
  );
});

self.addEventListener('fetch', event => {
  if (event.request.method !== 'GET') return;
  event.respondWith(
    caches.match(event.request).then(cached => {
      if (cached) return cached;
      return fetch(event.request).then(response => {
        if (response && response.ok && new URL(event.request.url).origin === self.location.origin) {
          const copy = response.clone();
          caches.open(CACHE_NAME).then(cache => cache.put(event.request, copy));
        }
        return response;
      }).catch(() => {
        if (event.request.mode === 'navigate') return caches.match('./index.html');
        return Response.error();
      });
    })
  );
});
