# Product brief — 今晚吃什么？ / What Are We Eating?

## Goal
Make the daily “what should I eat?” decision easier and playful, whether one person is choosing alone or two people are combining their food preferences. The app is mainly intended as a friendly food-picker that can be shared with a partner or friends through one public link.

## Primary experience
1. Choose **Just me** or **Two people**. Solo mode is the default and only uses Person 1's profile. Two-people mode combines both people's restrictions conservatively.
2. Pick breakfast, lunch, dinner or snack/dessert.
3. Choose takeaway, restaurant, maybe cook or cook at home. Takeaway is the default; cooking can remain occasional unless explicitly selected.
4. Set allergy, diet, dislike and spice preferences. Preferences are stored locally on this device.
5. Choose a playful mood; it changes probability but never overrides the safety/preference filters.
6. Spin through local dish illustrations and reveal a winner.
7. Allow two rerolls per round, avoid repeats in the round where possible, and reduce recent accepted repeats when enough alternatives exist.
8. Save favourites, record chosen meals and share the app or selected dish.

## Sharing and privacy
- Any person can open the same hosted URL independently.
- Each browser/device has its own local settings; there is no login, remote database or account.
- Settings do not sync across devices. For a shared meal decision on one device, select Two people and enter both preference profiles. For people choosing remotely, each person can use the same link on their own device and share a dish result.
- The published static files contain no personal preferences. Do not add private data to the project source.

## Design principles
- Mobile-first, fast taps, large touch targets, warm playful colours.
- Chinese dish name first, English translation second; include regional context and a short note.
- Offline-first: no remote fonts, APIs, tracking, image fetching or AI calls.
- The food database is editable in `food-data.js`; each bundled visual can be replaced by a local image.
- Hosted HTTPS builds can cache the project assets after first visit through the service worker.

## Food and allergy filtering
Dish data includes common possible allergen tags, typical diet tags, dislike tags, spice level, meal-time tags and cooking options. This is a screening aid only. Restaurant recipes and cross-contact vary, so never present the app as certifying a dish safe for an allergy.

## Acceptance criteria
- Essential UI, food data and 53 illustrations are local files.
- Solo mode uses only the first profile's preferences; two-person mode combines both profiles before selecting a dish.
- A mood can change the odds but cannot make an excluded dish appear.
- One normal spin plus two rerolls works without a page reload.
- Favourites and accepted-meal history persist locally when storage is available.
- The app-share button provides a public link after hosting; the dish-share button shares the selected result.
- On HTTPS, the service worker caches the app and illustrations for repeat offline visits.
- Empty filters explain how to review settings without encouraging the user to ignore a real allergy or dietary restriction.

## Future improvements
1. Replace illustrations with properly licensed local food photographs.
2. Add user-managed names for Person 1 / Person 2 if desired.
3. Optionally add a shareable “dish challenge” link or group voting flow; this would need a deliberate design decision about whether any data is stored remotely.
4. Verify typical ingredients against trusted recipes before expanding allergy-related tags; always retain the user-facing safety warning.
- **One-tap pork-free filter:** a private per-profile switch hides dishes tagged as pork or commonly prepared with pork; it can be turned off any time. Restaurant ingredients, broths, oils and cross-contact still need confirmation.
