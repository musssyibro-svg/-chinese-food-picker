# Publish the food picker and share one link

The project is a plain static website. It has no backend, account system, build step, database, or API. You can host it as static files and send the same URL to your girlfriend or friends.

## Fast route: Cloudflare Pages Direct Upload

1. Sign in to the Cloudflare dashboard.
2. Open **Workers & Pages**.
3. Choose **Create application** → **Get started** → **Drag and drop your files**.
4. Give the project a name, such as `what-are-we-eating`.
5. Upload this project's ZIP (`chinese-food-picker.zip`) or the extracted project folder. Upload the project root so `index.html` is at the top level; do not upload only the `food-images` folder.
6. Select **Deploy site**.
7. Cloudflare will provide a public `*.pages.dev` URL. Open it on your phone and test a spin, then send that URL to the people who should use the app.

Cloudflare's current Direct Upload instructions support a ZIP file or single folder with the dashboard drag-and-drop method. One caveat: a project created as a Direct Upload project cannot later be switched to Git integration; if you want Git-based automatic deployment, create a separate Git-integrated project instead.

Official instructions: https://developers.cloudflare.com/pages/get-started/direct-upload/

## After it is live

- In the app, the **Share app** button uses the device's native share sheet where supported, or copies/falls back to a copy prompt.
- The **Share this dish** button shares the selected Chinese and English dish names and its description, plus the app link when hosted.
- On a phone, visit the site once while online, then use your browser's **Add to Home Screen** option. The service worker caches the app and included illustrations for later offline visits.
- The app is public to anyone who has the link. Do not put private information in the public site files.

## What is private, and what is not

The published website contains only the app code and general food library. Allergy preferences, dislikes, favourites and recent picks are stored in each person's own browser storage, not uploaded to Cloudflare. People who open the same URL on different devices get separate local settings. There is no automatic cross-device sync.

## Updating it later

Edit the project locally, make sure the updated `index.html` and the rest of the assets are at the project root, then create a new deployment from Cloudflare Pages. If you change the offline files, bump `CACHE_NAME` in `service-worker.js` so previously installed versions refresh their cache.
## Pork-free preference

The current project includes a private **Pork-free dishes only** switch in each local profile. It persists in that browser only, supports separate profiles in two-person mode, and filters known pork dishes plus selected dishes commonly made with pork. Ingredient practices vary, so this is a useful screen—not a guarantee. Confirm meat, broth, sauces, oils and shared cooking equipment directly with the restaurant. The service-worker cache was bumped so a redeployment updates installed copies.
